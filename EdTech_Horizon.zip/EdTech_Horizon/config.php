<?php
// إعدادات الاتصال بـ Blockchain API
define('INFURA_ENDPOINT', 'https://mainnet.infura.io/v3/YOUR_INFURA_PROJECT_ID');
define('ALCHEMY_ENDPOINT', 'https://eth-mainnet.alchemyapi.io/v2/YOUR_ALCHEMY_API_KEY');
?>