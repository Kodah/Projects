<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // هنا يمكنك إضافة الكود لإرسال الرسالة إلى البريد الإلكتروني أو حفظها في قاعدة البيانات
    echo "Thank you, $name! Your message has been received.";
} else {
    echo "An error occurred while sending the message.";
}
?>