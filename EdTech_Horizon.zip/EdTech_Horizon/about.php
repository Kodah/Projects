<?php include 'config.php'; 
session_start(); // Start the session
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
}?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Smart Learning Platform</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

    <div class="video-background">
        <video autoplay muted loop id="bg-video">
            <source src="backgroundx.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>

    <header>
        <div class="logo">
            <a href="home.php"><img src="logo.png" alt="" href=></a>
        </div>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li>
                    <div class="vl"></div>
                </li>
                <li>
                    <div class="user-infoo">
                        <div class="dropdown">
                            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>

                            <div class="dropdown-content">
                                <a href="dashboard.php">Dashboard</a>
                                <a href="index.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </nav>
    </header>

    <section id="about">
        <h2>About Us</h2>
        <p>EdTech Horizon is a next-gen learning platform that combines <strong>Augmented Reality (AR)</strong>,
            <br> <strong>Virtual Reality (VR)</strong>, and <strong>Blockchain</strong> to create an immersive, secure,
            and engaging educational experience.
        </p>
        <p><strong>Interactive Learning:</strong> Explore 3D models, virtual labs, and gamified lessons.</p>
        <p><strong>Blockchain Security:</strong> Earn tamper-proof certificates and track achievements.</p>
        <p><strong>Gamified Rewards:</strong> Collect points from quizzes and tasks to unlock rewards.</p>
        <p><strong>Collaborate Anytime:</strong> Connect with teachers and peers in real-time virtual classrooms.</p>
    </section>

    <footer class="foot">
        <p>© 2025 EdTech Horizon Academy. All rights reserved.</p>
    </footer>
</body>

</html>