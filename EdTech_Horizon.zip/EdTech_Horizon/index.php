<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comcha Academy</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="wrapper">
    <header>
        <div class="logo">
        <a href="index.php"><img src="logo.png" alt="" href=></a>
        </div>
        <nav>
            <ul>
                <li><a href="LogIn.php">Login</a></li>
                <li><a href="SignUp.php">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <div class="video-background">
        <video autoplay muted loop id="bg-video">
            <source src="backgroundx.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>

    <button onclick="toggleVideo()" id="playPauseBtn">⏸︎</button>

<script>
    function toggleVideo() {
        let video = document.getElementById("bg-video");
        let btn = document.getElementById("playPauseBtn");

        if (video.paused) {
            video.play();
            btn.textContent = "⏸︎";
        } else {
            video.pause();
            btn.textContent = "▶";
        }
    }
</script> 

    <section id="home">
    <div class="hero">
        <h2>🚀 Welcome to EdTech Horizon! 🌐</h2>
        <p>EdTech Horizon is a next-gen learning platform that combines <strong>Augmented Reality (AR)</strong>,
       <br> <strong>Virtual Reality (VR)</strong>, and <strong>Blockchain</strong> to create an immersive, secure, and engaging educational experience.</p>
        <p><strong>Interactive Learning:</strong> Explore 3D models, virtual labs, and gamified lessons.</p>
        <p><strong>Blockchain Security:</strong> Earn tamper-proof certificates and track achievements.</p>
        <p><strong>Gamified Rewards:</strong> Collect points from quizzes and tasks to unlock rewards.</p>
        <p><strong>Collaborate Anytime:</strong> Connect with teachers and peers in real-time virtual classrooms.</p>
    </div>
</section>
    <footer>
        <p>© 2025 EdTech Horizon Academy. All rights reserved.</p>     
    </footer>
</div>
</body>
</html>