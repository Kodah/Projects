document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('formsContainer');
    const showSignup = container.dataset.showSignup === 'true';
    if (showSignup) container.classList.add('show-signup');

    document.querySelectorAll('.toggle-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const formType = link.dataset.form;
            container.classList.toggle('show-signup', formType === 'signup');
        });
    });

    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', (e) => {
            const inputs = form.querySelectorAll('input:not([type="hidden"])');
            let isValid = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('error');
                } else {
                    input.classList.remove('error');
                }
            });

            if (!isValid) {
                e.preventDefault();
                form.querySelector('.error-message').textContent = 'Please fill all fields';
            }
        });
    });
});