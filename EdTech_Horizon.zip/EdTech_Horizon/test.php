<?php
session_start(); // Start the session
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile Dropdown</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .profile-container {
            position: relative;
            display: inline-block;
        }
        .profile-btn {
            display: flex;
            align-items: center;
            background: none;
            border: none;
            cursor: pointer;
        }
        .profile-btn img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            background: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            width: 150px;
            border-radius: 5px;
        }
        .dropdown-menu a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: black;
        }
        .dropdown-menu a:hover {
            background: #f0f0f0;
        }
    </style>
</head>
<body>

<div class="profile-container">
    <button class="profile-btn" onclick="toggleMenu()">
        <img src="" alt="Profile Picture">
        <span> <?php echo htmlspecialchars($_SESSION['username']); ?> </span>
    </button>
    <div class="dropdown-menu" id="menu">
        <a href="#">Dashboard</a>
        <a href="#">Settings</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<script>
    function toggleMenu() {
        var menu = document.getElementById("menu");
        menu.style.display = menu.style.display === "block" ? "none" : "block";
    }
</script>

</body>
</html>
