<?php include 'config.php';
session_start(); // Start the session
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
}
?>

<?php
include 'db_edtech.php'; // تضمين ملف الاتصال بقاعدة البيانات

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $coins_to_add = 0; // عدد النقاط المضافة

    // زيادة النقاط في قاعدة البيانات
    try {
        $stmt = $conn->prepare("UPDATE users SET coins = coins + :coins WHERE id = :user_id");
        $stmt->bindParam(':coins', $coins_to_add);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        // تحديث النقاط في الجلسة
        if (isset($_SESSION['coins'])) {
            $_SESSION['coins'] += $coins_to_add;
        } else {
            $_SESSION['coins'] = $coins_to_add;
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "User not logged in.";
}
?>

<?php

// تخزين بيانات المستخدم بعد تسجيل الدخول (مثال)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    exit();
}

// تأكد من وجود المتغيرات في الجلسة قبل استخدامها
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';
$coins = isset($_SESSION['coins']) ? $_SESSION['coins'] : 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comcha Academy</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="wrapper">
        <header>
            <div class="logo">
                <a href="home.php"><img src="logo.png" alt="EdTech Horizon Logo"></a>
            </div>
            <nav>
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="courses.php">Courses</a></li>
                    <li><a href="about.php">about</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li>
                        <div class="vl"></div>
                    </li>
                    <li>
                        <div class="coins-display">
                            <span class="coins-icon">🪙</span> <!-- أيقونة النقاط -->
                            <span class="coins-amount"><?php echo $_SESSION['coins']; ?></span> <!-- عرض عدد النقاط -->
                        </div>
                    </li>
                    <li>
                        <div class="user-infoo">
                            <div class="dropdown">
                                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>

                                <div class="dropdown-content">
                                    <a href="dashboard.php">Dashboard</a>
                                    <a href="index.php">Logout</a>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </nav>
        </header>

        <div class="video-background">
            <video autoplay muted loop id="bg-video">
                <source src="backgroundx.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>

        <button onclick="toggleVideo()" id="playPauseBtn">⏸︎</button>

        <script>
            function toggleVideo() {
                let video = document.getElementById("bg-video");
                let btn = document.getElementById("playPauseBtn");

                if (video.paused) {
                    video.play();
                    btn.textContent = "⏸︎";
                } else {
                    video.pause();
                    btn.textContent = "▶";
                }
            }
        </script>

        <section id="home">
            <div class="hero">
                <h2>🚀 Welcome to EdTech Horizon! 🌐</h2>
                <p>EdTech Horizon is a next-gen learning platform that combines <strong>Augmented Reality (AR)</strong>,
                    <br> <strong>Virtual Reality (VR)</strong>, and <strong>Blockchain</strong> to create an immersive,
                    secure, and engaging educational experience.
                </p>
                <p><strong>Interactive Learning:</strong> Explore 3D models, virtual labs, and gamified lessons.</p>
                <p><strong>Blockchain Security:</strong> Earn tamper-proof certificates and track achievements.</p>
                <p><strong>Gamified Rewards:</strong> Collect points from quizzes and tasks to unlock rewards.</p>
                <p><strong>Collaborate Anytime:</strong> Connect with teachers and peers in real-time virtual
                    classrooms.</p>
                <a href="courses.php" class="btn-primary">Explore Courses</a>
            </div>
        </section>
        <footer>
            <p>© 2025 EdTech Horizon Academy. All rights reserved.</p>
        </footer>
    </div>
</body>

</html>