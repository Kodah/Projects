<?php include 'config.php';
session_start(); // Start the session
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses - ComCha Academy</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body class="courses">

    <div class="video-background">
        <video autoplay muted loop id="bg-video">
            <source src="backgroundx.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>

    <header>
        <div class="logo">
            <a href="home.php"><img src="logo.png" alt="" href=></a>
        </div>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li>
                    <div class="vl"></div>
                </li>
                <li>
                    <div class="coins-display">
                        <span class="coins-icon">🪙</span> <!-- أيقونة النقاط -->
                        <span class="coins-amount"><?php echo $_SESSION['coins']; ?></span> <!-- عرض عدد النقاط -->
                    </div>
                </li>
                <li>
                    <div class="user-infoo">
                        <div class="dropdown">
                            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>

                            <div class="dropdown-content">
                                <a href="dashboard.php">Dashboard</a>
                                <a href="index.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <section id="courses">
        <h2 style="text-align:center">Available Courses</h2>
        <div class="course-list">
            <div class="course1-card">
                <h3>Blockchain Fundamentals</h3>
                <p>Learn the basics of Blockchain technology and how to apply it.</p>
                <button class="btn-enroll">Enroll Now</button>
            </div>
            <div class="course2-card">
                <h3>Smart Contract Development</h3>
                <p>Learn how to build decentralized applications using Solidity.</p>
                <button class="btn-enroll">Enroll Now</button>
            </div>
        </div>
    </section>

    <footer class="foot">
        <p>© 2025 EdTech Horizon Academy. All rights reserved.</p>
    </footer>
</body>

</html>