<?php
include("db_edtech.php");
// معالجة بيانات تسجيل الدخول
$login_error = ""; // متغير لتخزين رسائل الخطأ

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // تسجيل الدخول ناجح
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: home.php"); // توجيه المستخدم إلى الصفحة الرئيسية
            exit();
        } else {
            // تسجيل الدخول فاشل
            $login_error = "Invalid username or password.";
        }
    } catch (PDOException $e) {
        $login_error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EdTech Horizon</title>
    <link rel="stylesheet" href="styles.css"> <!-- ربط ملف CSS -->
</head>
<body class="logbody">
    <div class="login-container">
        <div class="login-box">
            <h2>Login to EdTech Horizon</h2>
            <?php if (!empty($login_error)): ?>
                <div class="error-message"><?php echo $login_error; ?></div>
            <?php endif; ?>
            <form action="login.php" method="POST">
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn-login">Login</button>
            </form>
            <div class="extra-links">
                <a href="#">Forgot Password?</a>
                <a href="SignUp.php">Create an Account</a> <!-- رابط إلى صفحة التسجيل -->
            </div>
        </div>
    </div>
</body>
</html>