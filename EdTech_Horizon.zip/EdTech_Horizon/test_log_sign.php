<?php
session_start();
include("db_edtech.php");

$login_error = $signup_error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['form_type'])) {
        // Handle Login
        if ($_POST['form_type'] === 'LogIn') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            try {
                $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
                $stmt->bindParam(':username', $username);
                $stmt->execute();
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user && password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    header("Location: home.php");
                    exit();
                } else {
                    $login_error = "Invalid username or password.";
                }
            } catch (PDOException $e) {
                $login_error = "Error: " . $e->getMessage();
            }
        }

        // Handle Signup
        if ($_POST['form_type'] === 'SignUp') {
            $username = $_POST['username'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';

            if ($password !== $confirm_password) {
                $signup_error = "Passwords do not match.";
            } else {
                try {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
                    $stmt->bindParam(':username', $username);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':password', $hashed_password);
                    $stmt->execute();

                    $_SESSION['signup_success'] = true;
                    header("Location: home.php");
                    exit();
                } catch (PDOException $e) {
                    $signup_error = "Error: " . $e->getMessage();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EdTech Horizon - Auth</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body class="logbody">
    <div class="forms-container" id="formsContainer" data-show-signup="<?= !empty($signup_error) ? 'true' : 'false' ?>">
        <div class="form-wrapper">
            <!-- Login Form -->
            <div class="form-page">
                <div class="login-container">
                    <?php if (isset($_SESSION['signup_success'])): ?>
                        <div class="success-message">Registration successful! Please login</div>
                        <?php unset($_SESSION['signup_success']); ?>
                    <?php endif; ?>
                    <h2>Login to EdTech Horizon</h2>
                    <?php if (!empty($login_error)): ?>
                        <div class="error-message"><?= $login_error ?></div>
                    <?php endif; ?>
                    <form action="test_log_sign" method="POST">
                        <input type="hidden" name="form_type" value="login">
                        <div class="input-group">
                            <label for="login-username">Username</label>
                            <input type="text" id="login-username" name="username" required>
                        </div>
                        <div class="input-group">
                            <label for="login-password">Password</label>
                            <input type="password" id="login-password" name="password" required>
                        </div>
                        <button type="submit" class="btn-login">Login</button>
                        <p class="extra-links">
                            <a href="#" class="text-link">Forgot Password?</a>
                            <span class="toggle-link" data-form="signup">Sign Up</span>
                        </p>
                    </form>
                </div>
            </div>

            <!-- Signup Form -->
            <div class="form-page">
                <div class="login-container">
                    <h2>Sign Up for EdTech Horizon</h2>
                    <?php if (!empty($signup_error)): ?>
                        <div class="error-message"><?= $signup_error ?></div>
                    <?php endif; ?>
                    <form action="test_log_sign" method="POST">
                        <input type="hidden" name="form_type" value="signup">
                        <div class="input-group">
                            <label for="signup-username">Username</label>
                            <input type="text" id="signup-username" name="username" required>
                        </div>
                        <div class="input-group">
                            <label for="signup-email">Email</label>
                            <input type="email" id="signup-email" name="email" required>
                        </div>
                        <div class="input-group">
                            <label for="signup-password">Password</label>
                            <input type="password" id="signup-password" name="password" required>
                        </div>
                        <div class="input-group">
                            <label for="signup-confirm-password">Confirm Password</label>
                            <input type="password" id="signup-confirm-password" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn-login">Sign Up</button>
                        <p class="extra-links">
                            <span class="toggle-link" data-form="login">Already have an account? Login</span>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>