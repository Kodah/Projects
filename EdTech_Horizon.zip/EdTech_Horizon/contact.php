<?php include 'config.php';
session_start(); // Start the session
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Smart Learning Platform</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

    <div class="video-background">
        <video autoplay muted loop id="bg-video">
            <source src="backgroundx.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>

    <header>
        <div class="logo">
            <a href="home.php"><img src="logo.png" alt="" href=></a>
        </div>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li>
                    <div class="vl"></div>
                </li>
                <li>
                    <div class="user-infoo">
                        <div class="dropdown">
                            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>

                            <div class="dropdown-content">
                                <a href="dashboard.php">Dashboard</a>
                                <a href="index.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </nav>
    </header>

    <section id="contact">
        <h2>Contact Us</h2>
        <form action="send_message.php" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" required></textarea>
            <button type="submit" class="btn-primary">Send</button>
        </form>
    </section>

    <footer class="foot">
        <p>© 2025 EdTech Horizon Academy. All rights reserved.</p>
    </footer>
</body>

</html>